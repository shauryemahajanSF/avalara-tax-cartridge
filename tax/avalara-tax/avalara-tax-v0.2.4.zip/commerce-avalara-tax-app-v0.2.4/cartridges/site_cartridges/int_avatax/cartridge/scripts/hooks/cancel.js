'use strict';

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var avataxHelper = require('~/cartridge/scripts/helpers/avataxHelper');

var logger = Logger.getLogger('AvaTax', 'cancel');

/**
 * Void tax transaction with AvaTax when an order is cancelled or fails.
 *
 * @param {dw.order.Order} order - The order being cancelled
 * @returns {dw.system.Status} Status indicating success or failure
 */
exports.cancel = function (order) {
    if (!avataxHelper.getConfig().enabled) {
        logger.warn('AvaTax not enabled for this site');
        return new Status(Status.OK);
    }

    var orderNo = order.getOrderNo();

    try {
        var response = avataxHelper.voidTransaction(orderNo);

        if (!response.success) {
            logger.error('AvaTax void failed for order ' + orderNo + ': ' + response.error);
            return new Status(Status.ERROR, 'TAX_VOID_FAILED', 'Failed to void tax: ' + response.error);
        }

        return new Status(Status.OK, 'Tax transaction voided: ' + orderNo);
    } catch (e) {
        logger.error('Exception during tax void for order ' + orderNo + ': ' + e.message + '\n' + e.stack);
        return new Status(Status.ERROR, 'TAX_VOID_FAILED', 'Failed to void tax: ' + e.message);
    }
};
