'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

var CONNECTOR_NAME = 'AvaTax for SFCC';
var CONNECTOR_VERSION = '1.0';

/**
 * Creates and returns the AvaTax REST service instance.
 * Service ID "avatax.rest.all" must be configured in BM > Administration > Operations > Services.
 *
 * @returns {dw.svc.HTTPService} The service instance
 */
function getService() {
    return LocalServiceRegistry.createService('avatax.rest.all', {
        createRequest: function (svc, args) {
            svc.addHeader('Accept', 'application/json');
            svc.addHeader('Content-Type', 'application/json');
            svc.addHeader('X-Avalara-Client', CONNECTOR_NAME + ' || ' + CONNECTOR_VERSION);

            var credential = svc.getConfiguration().getCredential();
            var user = credential.getUser();
            var password = credential.getPassword();
            var encodedAuth = require('dw/util/StringUtils').encodeBase64(user + ':' + password);
            svc.addHeader('Authorization', 'Basic ' + encodedAuth);

            svc.setRequestMethod(args.method);
            var baseUrl = credential.getURL().replace(/\/+$/, '');
            svc.setURL(baseUrl + args.endpoint);

            if (args.body) {
                return JSON.stringify(args.body);
            }
            return null;
        },
        parseResponse: function (svc, client) {
            return client.text;
        },
        filterLogMessage: function (msg) {
            return msg;
        }
    });
}

/**
 * Makes an authenticated HTTP request to the AvaTax REST API via the SFCC service framework.
 *
 * @param {string} method - HTTP method (POST, GET, etc.)
 * @param {string} endpoint - API endpoint path (e.g. /api/v2/transactions/create)
 * @param {Object|null} body - Request body to send as JSON, or null
 * @returns {Object} Response object with {success: boolean, data: Object, error: String, latency: number}
 */
function call(method, endpoint, body) {
    var beforeTime = Date.now();

    try {
        var svc = getService();
        var result = svc.call({
            method: method,
            endpoint: endpoint,
            body: body
        });

        var latency = Date.now() - beforeTime;

        if (result.status === 'OK') {
            return {
                success: true,
                data: JSON.parse(result.object),
                latency: latency
            };
        }

        var errorText = result.errorMessage || result.msg || 'Unknown error';
        var errorDetails = {};
        try {
            errorDetails = JSON.parse(errorText);
        } catch (e) {
            // errorText is not JSON
        }

        return {
            success: false,
            error: 'AvaTax API error: ' + result.status,
            details: errorDetails,
            latency: latency
        };
    } catch (e) {
        var errorLatency = Date.now() - beforeTime;
        return {
            success: false,
            error: e.message,
            latency: errorLatency
        };
    }
}

module.exports = {
    call: call,
    CONNECTOR_NAME: CONNECTOR_NAME,
    CONNECTOR_VERSION: CONNECTOR_VERSION
};
