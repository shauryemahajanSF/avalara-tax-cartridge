'use strict';

var server = require('server');
var Site = require('dw/system/Site');
var Logger = require('dw/system/Logger');
var OrderMgr = require('dw/order/OrderMgr');
var avataxHelper = require('~/cartridge/scripts/helpers/avataxHelper');

var logger = Logger.getLogger('AvaTax', 'AvataxTest');

/**
 * Checks if ATEnableTesting preference is enabled; sends 403 JSON if not.
 * @param {Object} req - Request
 * @param {Object} res - Response
 * @param {Function} next - Next middleware
 */
function requireTesting(req, res, next) {
    if (!Site.getCurrent().getCustomPreferenceValue('ATEnableTesting')) {
        res.json({ success: false, error: 'Testing is not enabled. Enable ATEnableTesting in Site Preferences.' });
        return;
    }
    next();
}

server.get('Connect', server.middleware.https, requireTesting, function (req, res, next) {
    try {
        var result = avataxHelper.testConnection();
        if (result.success && result.authenticated) {
            res.json({
                success: true,
                message: 'Connection successful. User authenticated. Account ID: ' + (result.data.authenticatedAccountId || 'N/A')
            });
        } else if (result.success && !result.authenticated) {
            res.json({
                success: false,
                message: 'Service reachable but user NOT authenticated. Check credentials.'
            });
        } else {
            res.json({
                success: false,
                message: 'Connection failed: ' + result.error
            });
        }
    } catch (e) {
        logger.error('TestConnection exception: ' + e.message);
        res.json({ success: false, error: e.message });
    }
    next();
});

server.get('CommitDocument', server.middleware.https, requireTesting, function (req, res, next) {
    var orderNo = req.querystring.orderno;
    if (!orderNo) {
        res.json({ success: false, error: 'Missing orderno parameter' });
        next();
        return;
    }

    var order = OrderMgr.getOrder(orderNo);
    if (!order) {
        res.json({ success: false, error: 'Order ' + orderNo + ' not found' });
        next();
        return;
    }

    try {
        var response = avataxHelper.commitTransaction(orderNo);
        if (response.success) {
            res.json({ success: true, message: 'Document committed. Transaction ID: ' + orderNo });
        } else {
            res.json({ success: false, error: response.error || 'Commit failed' });
        }
    } catch (e) {
        logger.error('TestCommit exception for order ' + orderNo + ': ' + e.message);
        res.json({ success: false, error: e.message });
    }
    next();
});

server.get('VoidDocument', server.middleware.https, requireTesting, function (req, res, next) {
    var orderNo = req.querystring.orderno;
    if (!orderNo) {
        res.json({ success: false, error: 'Missing orderno parameter' });
        next();
        return;
    }

    var order = OrderMgr.getOrder(orderNo);
    if (!order) {
        res.json({ success: false, error: 'Order ' + orderNo + ' not found' });
        next();
        return;
    }

    try {
        var response = avataxHelper.voidTransaction(orderNo);
        if (response.success) {
            res.json({ success: true, message: 'Document voided. Transaction ID: ' + orderNo });
        } else {
            res.json({ success: false, error: response.error || 'Void failed' });
        }
    } catch (e) {
        logger.error('TestVoid exception for order ' + orderNo + ': ' + e.message);
        res.json({ success: false, error: e.message });
    }
    next();
});

module.exports = server.exports();
