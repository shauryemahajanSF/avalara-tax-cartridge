'use strict';

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var avataxHelper = require('~/cartridge/scripts/helpers/avataxHelper');

var logger = Logger.getLogger('AvaTax', 'commit');

/**
 * Commit tax transaction with AvaTax after order placement.
 *
 * @param {dw.order.Order} order - The placed order
 * @returns {dw.system.Status} Status indicating success or failure
 */
exports.commit = function (order) {
    if (!avataxHelper.getConfig().enabled) {
        logger.warn('AvaTax not enabled for this site');
        return new Status(Status.OK);
    }

    var orderNo = order.getOrderNo();

    try {
        var response = avataxHelper.commitTransaction(orderNo);

        if (!response.success) {
            logger.error('AvaTax commit failed for order ' + orderNo + ': ' + response.error);
            return new Status(Status.ERROR, 'TAX_COMMIT_FAILED', 'Failed to commit tax: ' + response.error);
        }

        return new Status(Status.OK, 'Tax transaction committed: ' + orderNo);
    } catch (e) {
        logger.error('Exception during tax commit for order ' + orderNo + ': ' + e.message + '\n' + e.stack);
        return new Status(Status.ERROR, 'TAX_COMMIT_FAILED', 'Failed to commit tax: ' + e.message);
    }
};
