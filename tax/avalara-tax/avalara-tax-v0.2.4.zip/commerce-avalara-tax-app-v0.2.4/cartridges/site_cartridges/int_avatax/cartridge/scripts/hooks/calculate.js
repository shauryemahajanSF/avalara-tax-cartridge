'use strict';

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var Transaction = require('dw/system/Transaction');
var avataxHelper = require('~/cartridge/scripts/helpers/avataxHelper');

var logger = Logger.getLogger('AvaTax', 'calculate');
/**
 * Calculate taxes using the AvaTax API.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order to calculate taxes for
 * @returns {dw.system.Status} Status indicating success or failure
 */
exports.calculate = function(lineItemCtnr) {
    if (!avataxHelper.getConfig().enabled) {
        logger.warn('AvaTax not enabled for this site');
        return new Status(Status.OK);
    }

    if (!lineItemCtnr) {
        logger.warn('Empty basket passed to tax calculation');
        return new Status(Status.OK);
    }

    try {
        var buildResult = avataxHelper.buildTransactionModel(lineItemCtnr);
        var transactionModel = buildResult.model;
        var lineUUIDMap = buildResult.lineUUIDMap;

        if (!transactionModel.lines || transactionModel.lines.length === 0) {
            logger.warn('No taxable line items found in basket');
            return new Status(Status.OK, "No taxable items");
        }

        var response = avataxHelper.callAvaTaxAPI(transactionModel);

        if (!response.success) {
            logger.error('AvaTax API call failed: ' + response.error);

            // Fall back to zero tax on error
            Transaction.wrap(function() {
                setZeroTax(lineItemCtnr);
            });

            return new Status(Status.OK, "Tax calculation failed, applied zero tax");
        }

        if (response.deduplicated) {
            return new Status(Status.OK, "Taxes unchanged");
        }

        Transaction.wrap(function() {
            avataxHelper.applyTaxesToBasket(lineItemCtnr, response.data, lineUUIDMap);
        });

        return new Status(Status.OK, "Taxes calculated via AvaTax");
    } catch (e) {
        logger.error('Error during tax calculation: ' + e.message + '\n' + e.stack);

        // Fall back to zero tax on exception
        Transaction.wrap(function() {
            setZeroTax(lineItemCtnr);
        });

        return new Status(Status.ERROR, "Tax calculation exception");
    }
};

/**
 * Sets all line items to zero tax (fallback for errors)
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order
 */
function setZeroTax(lineItemCtnr) {
    var Money = require('dw/value/Money');
    var zeroTax = new Money(0, lineItemCtnr.getCurrencyCode());

    var lineItems = lineItemCtnr.getAllLineItems().iterator();
    while (lineItems.hasNext()) {
        var lineItem = lineItems.next();
        try {
            // Reset price to net before zeroing tax (required for tax-inclusive pricing)
            if ('netPrice' in lineItem && lineItem.netPrice) {
                lineItem.setPriceValue(lineItem.netPrice.value);
            }
            lineItem.setTax(zeroTax);
            lineItem.updateTax(0);
        } catch (e) {
            // Some line items may not support tax (e.g., price adjustments)
        }
    }
}

